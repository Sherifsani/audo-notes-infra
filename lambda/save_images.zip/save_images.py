import json
import boto3
import datetime
import base64
import uuid
import logging
import re

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    s3 = boto3.client('s3')

    try:
        bucket_name = f'upload-bucket-{datetime.datetime.now().strftime("%Y-%m-%d")}'
        logger.info(f"Target bucket: {bucket_name}")

        existing_buckets = s3.list_buckets()
        if not any(b['Name'] == bucket_name for b in existing_buckets['Buckets']):
            s3.create_bucket(Bucket=bucket_name)
            logger.info(f"Created bucket: {bucket_name}")
        else:
            logger.info(f"Bucket already exists: {bucket_name}")

        body = event["body"]
        is_base64 = event.get("isBase64Encoded", False)

        def extract_base64_data(data_str):
            # Strip data URL header if present
            match = re.match(r'data:(.*?);base64,(.*)', data_str)
            if match:
                mime_type = match.group(1)
                base64_data = match.group(2)
            else:
                mime_type = None
                base64_data = data_str
            return base64_data.strip(), mime_type

        def detect_file_type(image_bytes):
            if image_bytes.startswith(b'\xff\xd8\xff'):
                return 'jpg', 'image/jpeg'
            elif image_bytes.startswith(b'\x89PNG\r\n\x1a\n'):
                return 'png', 'image/png'
            elif image_bytes.startswith(b'GIF87a') or image_bytes.startswith(b'GIF89a'):
                return 'gif', 'image/gif'
            elif image_bytes.startswith(b'BM'):
                return 'bmp', 'image/bmp'
            elif image_bytes.startswith(b'RIFF') and b'WEBP' in image_bytes[:12]:
                return 'webp', 'image/webp'
            return 'bin', 'application/octet-stream'

        image_bytes = None
        content_type = None

        if is_base64:
            base64_data, mime_type = extract_base64_data(body)
            image_bytes = base64.b64decode(base64_data)
        else:
            try:
                json_body = json.loads(body)
                base64_data, mime_type = extract_base64_data(json_body.get("body", ""))
                image_bytes = base64.b64decode(base64_data)
            except Exception:
                logger.warning("Could not decode JSON or base64, using raw bytes")
                base64_data, mime_type = extract_base64_data(body)
                try:
                    image_bytes = base64.b64decode(base64_data)
                except Exception:
                    image_bytes = body.encode("utf-8")

        file_ext, detected_type = detect_file_type(image_bytes)
        if mime_type:
            content_type = mime_type
        else:
            content_type = detected_type

        filename = f"{uuid.uuid4()}.{file_ext}"
        logger.info(f"Detected file type: {file_ext}, content type: {content_type}, size: {len(image_bytes)} bytes")

        s3.put_object(
            Bucket=bucket_name,
            Key=filename,
            Body=image_bytes,
            ContentType=content_type
        )

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f"Image uploaded as '{filename}'",
                'bucket': bucket_name,
                'key': filename
            })
        }

    except Exception as e:
        logger.error(f"Error occurred: {str(e)}", exc_info=True)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
